import './Contact.css';
import Header from '../../components/Header/Header'

export default function Contact() {
    return (
        <>
            <Header />
            <h2>Contact</h2>
        </>
    )
}