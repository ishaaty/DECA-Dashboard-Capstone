import './About.css';
import Header from '../../components/Header/Header'

export default function About() {
    return (
        <>
            <Header />
            <h2>About</h2>
        </>
    )
}