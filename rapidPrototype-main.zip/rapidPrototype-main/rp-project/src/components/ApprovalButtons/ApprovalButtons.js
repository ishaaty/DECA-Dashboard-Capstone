import './ApprovalButtons.css'

export default function ApprovalButtons() {
    return (
        <>
            <div class="approvecont">
                <button id="approve">Approve Request</button>
                <button id="deny">Deny Request</button>
            </div>
        </>
    )
}